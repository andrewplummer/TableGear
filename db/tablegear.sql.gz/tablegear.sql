-- phpMyAdmin SQL Dump
-- version 3.4.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 08, 2012 at 07:47 PM
-- Server version: 5.1.56
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `andrewpl_demos`
--

-- --------------------------------------------------------

--
-- Table structure for table `example1`
--

CREATE TABLE IF NOT EXISTS `example1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2658 ;

--
-- Dumping data for table `example1`
--

INSERT INTO `example1` (`id`, `item`, `description`, `price`, `quantity`) VALUES
(2647, '6', '45', 5, 5),
(2648, 'dfgh', '6', 6, 0),
(2652, 'fd', 'df', 5, 5),
(2653, 'fd', '5', 5, 0),
(2654, '6', 'gh', 5, 5),
(2655, '6', '5', 5, 5),
(2656, '6', '6', 5, 5),
(2657, '6', '5', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `example2`
--

CREATE TABLE IF NOT EXISTS `example2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1372 ;

--
-- Dumping data for table `example2`
--

INSERT INTO `example2` (`id`, `item`, `description`, `price`, `date`, `quantity`) VALUES
(1347, 'ffffffffffffffffff', NULL, 6236, 4, 1000),
(1349, 'eee', '', 34, 1, 78),
(1351, '7976', '7689', 789, 1666567, 200),
(1365, 'f', '1000', 1000, 2, NULL),
(1366, 'fgh', NULL, 57000, 3, NULL),
(1367, 'fgh', NULL, NULL, 4, 90),
(1369, 'asfd', 'asdf', 0, 0, 0),
(1371, 'nose', 'asdjakdjas', 500000, 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `example3`
--

CREATE TABLE IF NOT EXISTS `example3` (
  `thumbnail` varchar(20) NOT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=731 ;

--
-- Dumping data for table `example3`
--

INSERT INTO `example3` (`thumbnail`, `id`, `item`, `description`, `price`, `date`, `quantity`) VALUES
('abc.jpg', 721, 'xxx', 'test data by pb', 7979, 0, 50),
('dem.jpg', 724, NULL, NULL, 25, NULL, 85),
('nic4e.jpg', 725, 'adqweqw', 'sdfgsdfgs', 2, NULL, NULL),
('Â¡', 730, NULL, 'sdfgsdfg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `example4`
--

CREATE TABLE IF NOT EXISTS `example4` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=738 ;

--
-- Dumping data for table `example4`
--

INSERT INTO `example4` (`id`, `item`, `description`, `price`, `date`, `quantity`) VALUES
(652, '1', 'alo', 5000, 0, 777),
(655, '2', 'akex', 36985, 0, 100),
(658, '3', 'dddddvvv', 854, 0, 20),
(659, '4', 'aaaaaaaaa', 8955, 0, 35),
(660, '5', 'fsdf', 100, 87, 100),
(661, '69', 'wqeqwe', 19, 1, 123),
(662, 'w', 'fdgdsgfsd', 36, 11, 5),
(663, '8', 'dd', 60, 1, 0),
(664, '50', ',bkjkjb', 0, 0, 50),
(665, '10', '9779', 200, 0, 45),
(666, '11', '787', 200, 888, 1),
(667, '12', 'castro baca raul', 0, 123, 233),
(668, '15', 'yyyy', 20, 6564, 666),
(669, '14', '213', 45, 16, 0),
(670, '15', '222hjhj', 123, 0, 2342),
(671, '6666777', 'gjhjhjjh', 20, 25, 1),
(672, '17', 'The Man 2', 94, 50, 1258),
(673, '18', 'asd', 8, 2010, 10),
(674, '19', 'This is a test row...', 3, 123, 1),
(675, '20', 'Hello<br />egz<br />eef', 0, 12456, 0),
(676, '21', 'dsf', 555555, 43, 45),
(677, '33', 'dsf', 1.23455, 12000, 555),
(678, '10', 'dsf', 325, 20091212, 32),
(679, '24', 'dfdsf', 250, 12, 12),
(680, '25', 'dsf', 0, 12, 32),
(681, '2', 'ewqd', 222, 0, 1),
(682, '27', 'Nossa, que massa!ghnjghnj', 330, 0, 2011),
(683, '28', 'kjavkjb', 77777, 123, 33),
(684, '29', 'dfsdf34', 155, 121321, 32),
(685, '30', 'This is a test row...', 2323, 12, 30),
(686, '31', '2', 1.11111e+06, 98, 6),
(687, 'ddd', 'This is a test row...', 2554, 12, 88),
(688, '33', 'This is a test row...', 231.9, 13, 32),
(689, '34', 'This is a test row...', 232, 12, 32),
(690, '35', 'ghfg', 232, 2333, 32),
(691, '36', 'This is a test row...', 232, 44, 32),
(692, '99', 'This is a test row... kjkjkjk', 777, 999999, 0),
(693, '38', 'asdasd', 0, NULL, 0),
(694, '39', 'amf', 5, 0, 1000),
(695, '40', 'df', 7, 0, 0),
(696, 'asd', '15', 10, 56, 6767),
(697, '123', 'qqq', 7777, 123, 1),
(698, 'abc', '43623262', 0, 0, 0),
(699, '1', 'eee', 50, 789456123, 123),
(700, '444', '123', 7, 344, 0),
(701, 'December 31, 1969', 'sdfasdasdf', NULL, 66, 0),
(702, '555555555', 'bbbbbbbbbb', 0, 0, 0),
(703, 'hfgh', 'fghfgh', 0, 0, 0),
(704, 'que ', 'sadsdffsdfasdf111', NULL, NULL, 2),
(705, 'tal', 'prueba', 45, NULL, 0),
(706, 'hola', 'qwe', NULL, NULL, 13213),
(707, 'que', 'wqe', 0, 15, 111),
(708, '1', '43623262', NULL, NULL, 0),
(709, '2', 'kl', 445, NULL, 0),
(710, '3', '125', NULL, NULL, 0),
(711, '4', 'asdsad', 14, NULL, 0),
(712, '45', 'gfgg', 12, 0, 0),
(713, '45454', 'fg', 12321, 0, 0),
(714, 'sdfge4r', '3', 6, 0, 0),
(715, 'sadsadsa', 'sdsadas', 3, 24, 0),
(716, '5', 'hber :O', 800, 0, 0),
(717, '2', 'gfgf', -20, NULL, 0),
(718, 'hernan', 'rtyklÃ±kjhg', 20, NULL, NULL),
(719, 'e', '123456789', 0, NULL, 45),
(720, 'rosa', 'mayorga', 10, 0, NULL),
(721, 'g', 'gfgfg', NULL, NULL, NULL),
(722, ' bfbfb', 'v uiiuhjm', 5555, 98098, NULL),
(723, 'y', 'gfg', NULL, NULL, NULL),
(724, 't', 'fg', NULL, NULL, NULL),
(725, NULL, 'fgf', 0, 55555, NULL),
(726, 'e', 'gf', 89, NULL, NULL),
(727, NULL, 'gf', NULL, 100, 2147483647),
(728, NULL, 'gf', NULL, NULL, 0),
(729, NULL, 'g', NULL, NULL, NULL),
(730, NULL, 'fgfdgsdfg', NULL, NULL, NULL),
(731, 'sdfgsdfg', 'aaq', 1111, NULL, NULL),
(732, 'sadasd', 'asdfwqerwqer', NULL, 2, 5454646),
(733, NULL, 'fg', -0, NULL, NULL),
(734, '1000', 'fg', 0, NULL, NULL),
(735, '100', 'dfsdf', NULL, NULL, NULL),
(736, '99', 'gf', 500, 12, 10),
(737, '100', 'gf', 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `labs_tablegear`
--

CREATE TABLE IF NOT EXISTS `labs_tablegear` (
  `item` varchar(100) NOT NULL DEFAULT '',
  `description` tinytext,
  `area` smallint(6) NOT NULL DEFAULT '0',
  `zipcode` int(11) NOT NULL DEFAULT '0',
  `price` float DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` int(11) DEFAULT NULL,
  `memory` bigint(11) DEFAULT NULL,
  PRIMARY KEY (`area`,`zipcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `labs_tablegear`
--

INSERT INTO `labs_tablegear` (`item`, `description`, `area`, `zipcode`, `price`, `date`, `quantity`, `memory`) VALUES
('hmmz', NULL, 0, 0, NULL, '2010-06-29 16:50:18', NULL, NULL),
('woomz', 'sdfadsfadsfa', 0, 5345, NULL, '2010-09-26 17:13:00', NULL, NULL),
('', NULL, 0, 34534, 3424, '2010-07-29 15:47:51', NULL, NULL),
('', NULL, 32767, 0, NULL, '2010-07-29 15:47:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `labs_tablegear2`
--

CREATE TABLE IF NOT EXISTS `labs_tablegear2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field2` varchar(30) NOT NULL,
  `field3` varchar(30) NOT NULL,
  `field4` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=258 ;

--
-- Dumping data for table `labs_tablegear2`
--

INSERT INTO `labs_tablegear2` (`id`, `field2`, `field3`, `field4`) VALUES
(36, 'sdfs', 'asdf', 'sdfsdf'),
(243, 'cow wo', '', 'pool'),
(244, '', '', 'poop all over me!!'),
(246, 'lfdaksjfas', 'noway', ''),
(247, 'howk', 'barnone', ''),
(248, 'smock', 'farnone', ''),
(250, 'asfja', '', ''),
(251, 'sfasd', '', ''),
(252, 'fads', '', ''),
(254, 'sdf', '', ''),
(255, '', '', 'das'),
(256, 'pick', '', ''),
(257, 'kick', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tablegear`
--

CREATE TABLE IF NOT EXISTS `tablegear` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `memory` bigint(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1005 ;

--
-- Dumping data for table `tablegear`
--

INSERT INTO `tablegear` (`id`, `item`, `description`, `price`, `date`, `quantity`, `memory`) VALUES
(989, '4', '5', 6, 1523209347, 1, 24352457),
(992, NULL, NULL, 6, NULL, NULL, NULL),
(993, 'R', NULL, 6, NULL, NULL, NULL),
(995, NULL, NULL, 232, NULL, NULL, NULL),
(996, NULL, NULL, 2, NULL, NULL, NULL),
(997, NULL, NULL, 89, NULL, NULL, NULL),
(999, NULL, NULL, 88, NULL, NULL, NULL),
(1000, NULL, NULL, 10, NULL, NULL, NULL),
(1001, NULL, NULL, 96565, NULL, NULL, NULL),
(1002, NULL, NULL, 5.65657e+12, NULL, NULL, NULL),
(1003, NULL, NULL, 9.66367e+22, NULL, NULL, NULL),
(1004, 'dfs', 'sdf', 1.33333e+19, 345600, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `together`
--

CREATE TABLE IF NOT EXISTS `together` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `description` tinytext,
  `price` float DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `memory` bigint(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=185 ;

--
-- Dumping data for table `together`
--

INSERT INTO `together` (`id`, `item`, `description`, `price`, `date`, `quantity`, `memory`) VALUES
(167, 'Big Table', 'Just a simple table.', 384, 824028347, 12, 2343234),
(168, 'Chair', 'The comfy chair!', 63.47, 823664047, 0, 77266),
(170, 'Coffee', 'Freshness brewed.', 78.95, 1525591547, 64, 7785866),
(171, 'Juice', 'Actual fruit juice: 5%.', 67, 1214361547, -1, 933456),
(172, 'Desk', 'Nothing better than a huge desk.', 69, 1255500547, 3, 4577545),
(173, 'CD', 'These things have gotta be overpriced.', 17.99, 1284455147, 21, 345577),
(174, 'Tape', 'High quality audio tape.', 35.43, 1522604547, 35, 24352457),
(176, 'Book', 'Stop looking at the computer!', 15.95, 1285145147, 202, 57477544),
(177, 'Cup', 'Porcelain and indestructible.', 70.99, 1043574147, 10, 46575474),
(178, 'Shampoo', 'No tears for baby.', 36, 1013683547, 77, 4534534),
(179, 'Kleenex', 'Got the sniffles.', 63.99, 1285985947, 240, 6244),
(181, 'Car', 'Not a luxury mobile.', 2166, 751326347, 88, 232443),
(182, 'Computer', 'Blazing fast Pentium II.', 722, 923613947, 80, 6578),
(183, NULL, NULL, 8, -864000, 10, NULL),
(184, NULL, NULL, 1, NULL, 10, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
